-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 05 Agu 2019 pada 09.09
-- Versi server: 10.3.16-MariaDB
-- Versi PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skripsi_ales`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_bahan`
--

CREATE TABLE `tbl_bahan` (
  `id_bahan` int(11) NOT NULL,
  `nama_b` varchar(50) NOT NULL,
  `bahan_p` varchar(100) NOT NULL,
  `bahan_l` varchar(100) NOT NULL,
  `ukuran_b` varchar(50) NOT NULL,
  `ketebalan_b` varchar(50) NOT NULL,
  `harga_b` varchar(50) NOT NULL,
  `publish` enum('Yes','No') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_bahan`
--

INSERT INTO `tbl_bahan` (`id_bahan`, `nama_b`, `bahan_p`, `bahan_l`, `ukuran_b`, `ketebalan_b`, `harga_b`, `publish`) VALUES
(1, 'Art Paper', '650', '900', '', '120', 'Rp. 150.000', 'Yes'),
(2, 'Art Cartoon', '120', '96', '', '70', 'Rp. 100.000', 'Yes');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_biaya`
--

CREATE TABLE `tbl_biaya` (
  `id_biaya` int(11) NOT NULL,
  `jenis_biaya` varchar(50) NOT NULL,
  `jumlah_min` varchar(50) NOT NULL,
  `harga_min` varchar(50) NOT NULL,
  `harga_lebih` varchar(100) NOT NULL,
  `publish` enum('Yes','No') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_biaya`
--

INSERT INTO `tbl_biaya` (`id_biaya`, `jenis_biaya`, `jumlah_min`, `harga_min`, `harga_lebih`, `publish`) VALUES
(1, 'Insheet', '100', 'Rp. 100', 'Rp. 100', 'No');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_mesin`
--

CREATE TABLE `tbl_mesin` (
  `mesin_id` int(11) NOT NULL,
  `m_name` varchar(50) NOT NULL,
  `ukuran_max` varchar(50) NOT NULL,
  `ukuran_min` varchar(50) NOT NULL,
  `harga_min` varchar(50) NOT NULL,
  `harga_ctp` varchar(50) NOT NULL,
  `publish` enum('Yes','No') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_mesin`
--

INSERT INTO `tbl_mesin` (`mesin_id`, `m_name`, `ukuran_max`, `ukuran_min`, `harga_min`, `harga_ctp`, `publish`) VALUES
(1, 'Mesin Indigo', '320', '480', 'Rp. 1.000', 'Rp. 2.000', 'Yes'),
(4, 'test', '1', '1', 'Rp. 1', 'Rp. 1', 'No');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_trx_land`
--

CREATE TABLE `tbl_trx_land` (
  `trx_id` int(11) NOT NULL,
  `id_mesin` int(11) NOT NULL,
  `id_bahan` int(11) NOT NULL,
  `id_biaya` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_trx_land_det`
--

CREATE TABLE `tbl_trx_land_det` (
  `trx_det_id` int(11) NOT NULL,
  `trx_id` int(11) NOT NULL,
  `jumlah_cetak` varchar(100) NOT NULL,
  `biaya_desain` varchar(100) NOT NULL,
  `biaya_lain` varchar(100) NOT NULL,
  `total_biaya` varchar(100) NOT NULL,
  `margin` varchar(100) NOT NULL,
  `total_jual` varchar(100) NOT NULL,
  `harga satuan` varchar(100) NOT NULL,
  `datetime` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`user_id`, `nama`, `username`, `password`, `role_id`) VALUES
(1, 'admin', 'admin', '21232f297a57a5a743894a0e4a801fc3', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_role`
--

CREATE TABLE `user_role` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_role`
--

INSERT INTO `user_role` (`role_id`, `role_name`) VALUES
(1, 'Admin'),
(2, 'Kasir');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbl_bahan`
--
ALTER TABLE `tbl_bahan`
  ADD PRIMARY KEY (`id_bahan`);

--
-- Indeks untuk tabel `tbl_biaya`
--
ALTER TABLE `tbl_biaya`
  ADD PRIMARY KEY (`id_biaya`);

--
-- Indeks untuk tabel `tbl_mesin`
--
ALTER TABLE `tbl_mesin`
  ADD PRIMARY KEY (`mesin_id`);

--
-- Indeks untuk tabel `tbl_trx_land`
--
ALTER TABLE `tbl_trx_land`
  ADD PRIMARY KEY (`trx_id`);

--
-- Indeks untuk tabel `tbl_trx_land_det`
--
ALTER TABLE `tbl_trx_land_det`
  ADD PRIMARY KEY (`trx_det_id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD KEY `fk_role` (`role_id`);

--
-- Indeks untuk tabel `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`role_id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbl_bahan`
--
ALTER TABLE `tbl_bahan`
  MODIFY `id_bahan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `tbl_biaya`
--
ALTER TABLE `tbl_biaya`
  MODIFY `id_biaya` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tbl_mesin`
--
ALTER TABLE `tbl_mesin`
  MODIFY `mesin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `tbl_trx_land`
--
ALTER TABLE `tbl_trx_land`
  MODIFY `trx_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `tbl_trx_land_det`
--
ALTER TABLE `tbl_trx_land_det`
  MODIFY `trx_det_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `user_role`
--
ALTER TABLE `user_role`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_role` FOREIGN KEY (`role_id`) REFERENCES `user_role` (`role_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
