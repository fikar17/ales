<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Master_m extends CI_Model
{
    //bahan
    public function get_bahan($id_bahan = NULL)
    {
        if ($id_bahan == NULL) {
            $this->db->select("id_bahan,nama_b,ukuran_b,ketebalan_b,bahan_p,bahan_l,harga_b,publish,CONCAT(nama_b,' ',ketebalan_b,' ', 'gram') AS nama_bahan FROM tbl_bahan");
            $query = $this->db->get()->result();
            return json_encode(array('bahan_datab' => $query));
        } else {
            $query = $this->db->select('*')->from('tbl_bahan')->where('$id_bahan', $id_bahan)->get()->result();
            return json_encode(array('bahan_databs' => $query));
        }
    }

    public function gets_bahan()
    {
        $this->db->select('CONCAT(bahan_p,\' X \', bahan_l) AS Ukuran_Bahan, id_bahan, nama_b, ketebalan_b,harga_b, publish');
        $this->db->from('tbl_bahan');
        $query = $this->db->get()->result();
        return json_encode(array('bah_dat' => $query));
    }

    public function add_bahan($table, $data)
    {
        $this->db->insert($table, $data);
    }

    public function edit_bahan($data)
    {
        $this->db->where('id_bahan', $data['id_bahan'])->update('tbl_bahan', $data);
    }

    public function delete_bahan($id_bahan)
    {
        return $this->db->delete('tbl_bahan', array('id_bahan' => $id_bahan));

        $data = $this->db->where('id_bahan', $id_bahan);
        return $this->db->delete('tbl_bahan', $data);
    }

    //mesin
    public function get_mesin($mesin_id = NULL)
    {
        if ($mesin_id == NULL) {
            $this->db->select("mesin_id, m_name,harga_min,harga_ctp,insheet,publish,CONCAT(m_name,'-',ukuran_max,'x',ukuran_min) AS nama_mesin,ukuran_max,ukuran_min");
            $this->db->from('tbl_mesin');
            $query = $this->db->get()->result();
            return json_encode(array('mesin_datab' => $query));
        } else {
            $query = $this->db->select('*')->from('tbl_mesin')->where('mesin_id', $mesin_id)->get()->result();
            return json_encode(array('mesin_databs' => $query));
        }
    }

    public function get_coba_mesin()
    {
        $this->db->select("mesin_id, CONCAT(m_name,'-',ukuran_max,'x',ukuran_min) AS nama_mesin");
    }

    public function add_mesin($table, $data)
    {
        $this->db->insert($table, $data);
    }

    public function edit_mesin($data)
    {
        $this->db->where('mesin_id', $data['mesin_id'])->update('tbl_mesin', $data);
    }

    public function delete_mesin($mesin_id)
    {
        return $this->db->delete('tbl_mesin', array('mesin_id' => $mesin_id));

        $data = $this->db->where('mesin_id', $mesin_id);
        return $this->db->delete('tbl_mesin', $data);
    }

    //biaya
    public function get_biaya($id_biaya = NULL)
    {
        if ($id_biaya == NULL) {
            $query = $this->db->get('tbl_biaya')->result();
            return json_encode(array('biaya_datab' => $query));
        } else {
            $query = $this->db->select('*')->from('tbl_biaya')->where('$id_biaya', $id_biaya)->get()->result();
            return json_encode(array('biaya_databs' => $query));
        }
    }

    public function add_biaya($table, $data)
    {
        $this->db->insert($table, $data);
    }

    public function edit_biaya($data)
    {
        $this->db->where('id_biaya', $data['id_biaya'])->update('tbl_biaya', $data);
    }

    public function delete_biaya($id_biaya)
    {
        return $this->db->delete('tbl_biaya', array('id_biaya' => $id_biaya));

        $data = $this->db->where('id_biaya', $id_biaya);
        return $this->db->delete('tbl_biaya', $data);
    }
}

/* End of file Master_m.php */
