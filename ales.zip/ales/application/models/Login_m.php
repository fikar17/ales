<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Login_m extends CI_Model
{

    public function login($username, $password)
    {
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('username', $username);
        $this->db->where('password', $password);

        $return = $this->db->get('');

        if ($return->num_rows() > 0) {
            foreach ($return->result() as $hasil) {
                if ($hasil->role_id == "1") {
                    $hasilrow = json_decode(json_encode($hasil), true);
                    $session = array(
                        'role_id' => $hasilrow['role_id'],
                        'username' => $hasilrow['username'],
                        'nama' => $hasilrow['nama'],
                        'user_id' => $hasilrow['user_id']
                    );
                    $this->session->set_userdata($session);
                    echo "<script language='javascript'>alert('Anda Berhasil Login');</script>";

                    redirect('dashboard', 'refresh');
                } elseif ($hasil->role_id == "2") {
                    $hasilrow = json_decode(json_encode($hasil), true);
                    $session = array(
                        'role_id' => $hasilrow['role_id'],
                        'username' => $hasilrow['username'],
                        'nama' => $hasilrow['nama'],
                        'user_id' => $hasilrow['user_id']
                    );
                    $this->session->set_userdata($session);
                    echo "<script language='javascript'>alert('Anda Berhasil Login');</script>";

                    redirect('kasir', 'refresh');
                }
            }
        } else {
            $this->session->set_flashdata('pesan', 'Username dan Password Anda Tidak Cocok');

            redirect('admin');
        }
    }
}

/* End of file Login_m.php */
