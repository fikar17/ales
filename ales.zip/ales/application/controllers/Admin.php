<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{


    public function __construct()
    {
        parent::__construct();
        $this->load->model('login_m');
        $this->load->model('master_m');
    }

    public function index()
    {
        $this->load->view('template/header');
        $this->load->view('admin/index');
        $this->load->view('template/footer');
    }

    function proses_login()
    {
        $this->form_validation->set_rules('username', 'Username', 'trim|required');
        $this->form_validation->set_rules('password', 'Password', 'trim|required');
        $this->form_validation->set_error_delimiters('<span class="text-danger">', '</span>');

        if ($this->form_validation->run()) {
            $username = $this->input->post('username');
            $password = md5($this->input->post('password'));

            $this->login_m->login($username, $password);
        } else {
            $this->index();
        }
    }

    public function dashboard()
    {
        $this->load->view('template/header_dash');
        $this->load->view('template/topbar_dash');
        $this->load->view('template/sidebar_dash');
        $this->load->view('admin/dashboard');
        $this->load->view('template/footer_dash');
        $this->load->view('template/footer_js');
    }

    //Data Bahan
    public function bahan()
    {
        $data['form'] = 'Bahan';
        $data['bahan'] = json_decode($this->master_m->get_bahan(), true);
        $data['bah'] = json_decode($this->master_m->gets_bahan(), true);

        $this->load->view('template/header_dash');
        $this->load->view('template/topbar_dash');
        $this->load->view('template/sidebar_dash');
        $this->load->view('admin/bahan', $data);
        $this->load->view('template/footer_dash');
        $this->load->view('template/footer_js');
    }

    public function add_bahan()
    {
        $data = array(
            'nama_b' => $this->input->post('nama_b'),
            'bahan_p' => $this->input->post('bahan_p'),
            'bahan_l' => $this->input->post('bahan_l'),
            'ketebalan_b' => $this->input->post('ketebalan_b'),
            'harga_b' => $this->input->post('harga_b'),
            'publish' => $this->input->post('publish')
        );
        $this->master_m->add_bahan('tbl_bahan', $data);
        echo "<script language='javascript'>alert('Berhasil Disimpan');</script>";
        redirect('bahan', 'refresh');
    }

    public function edit_bahan()
    {
        $data = array(
            'id_bahan' => $this->input->post('id_bahan'),
            'nama_b' => $this->input->post('nama_b'),
            'bahan_p' => $this->input->post('bahan_p'),
            'bahan_l' => $this->input->post('bahan_l'),
            'ketebalan_b' => $this->input->post('ketebalan_b'),
            'harga_b' => $this->input->post('harga_b'),
            'publish' => $this->input->post('publish')
        );
        $this->master_m->edit_bahan($data);
        echo "<script language='javascript'>alert('Berhasil Diubah');</script>";
        redirect('bahan', 'refresh');
    }

    public function delete_bahan($id_bahan)
    {
        $this->master_m->delete_bahan($id_bahan);
        echo "<script language='javascript'>alert('Berhasil Dihapus');</script>";
        redirect('bahan', 'refresh');
    }

    //Master Mesin
    public function mesin()
    {
        $data['form'] = 'Mesin';
        $data['mesin'] = json_decode($this->master_m->get_mesin(), true);

        $this->load->view('template/header_dash');
        $this->load->view('template/topbar_dash');
        $this->load->view('template/sidebar_dash');
        $this->load->view('admin/mesin', $data);
        $this->load->view('template/footer_dash');
        $this->load->view('template/footer_js');
    }

    public function add_mesin()
    {
        $data = array(
            'm_name' => $this->input->post('m_name'),
            'ukuran_max' => $this->input->post('ukuran_max'),
            'ukuran_min' => $this->input->post('ukuran_min'),
            'harga_min' => $this->input->post('harga_min'),
            'harga_ctp' => $this->input->post('harga_ctp'),
            'insheet' => $this->input->post('insheet'),
            'publish' => $this->input->post('publish')
        );
        $this->master_m->add_mesin('tbl_mesin', $data);
        echo "<script language='javascript'>alert('Berhasil Disimpan');</script>";
        redirect('mesin', 'refresh');
    }

    public function edit_mesin()
    {
        $data = array(
            'mesin_id' => $this->input->post('mesin_id'),
            'm_name' => $this->input->post('m_name'),
            'ukuran_max' => $this->input->post('ukuran_max'),
            'ukuran_min' => $this->input->post('ukuran_min'),
            'harga_min' => $this->input->post('harga_min'),
            'harga_ctp' => $this->input->post('harga_ctp'),
            'insheet' => $this->input->post('insheet'),
            'publish' => $this->input->post('publish')
        );
        $this->master_m->edit_mesin($data);
        echo "<script language='javascript'>alert('Berhasil Diubah');</script>";
        redirect('mesin', 'refresh');
    }

    public function delete_mesin($mesin_id)
    {
        $this->master_m->delete_mesin($mesin_id);
        echo "<script language='javascript'>alert('Berhasil Dihapus');</script>";
        redirect('mesin', 'refresh');
    }

    //Master Biaya
    public function biaya()
    {
        $data['form'] = 'Biaya';
        $data['biaya'] = json_decode($this->master_m->get_biaya(), true);

        $this->load->view('template/header_dash');
        $this->load->view('template/topbar_dash');
        $this->load->view('template/sidebar_dash');
        $this->load->view('admin/biaya', $data);
        $this->load->view('template/footer_dash');
        $this->load->view('template/footer_js');
    }

    public function add_biaya()
    {
        $data = array(
            'jenis_biaya' => $this->input->post('jenis_biaya'),
            'harga' => $this->input->post('harga'),
            'publish' => $this->input->post('publish')
        );
        $this->master_m->add_biaya('tbl_biaya', $data);
        echo "<script language='javascript'>alert('Berhasil Disimpan');</script>";
        redirect('biaya', 'refresh');
    }

    public function edit_biaya()
    {
        $data = array(
            'id_biaya' => $this->input->post('id_biaya'),
            'jenis_biaya' => $this->input->post('jenis_biaya'),
            'harga' => $this->input->post('harga'),
            'publish' => $this->input->post('publish')
        );
        $this->master_m->edit_biaya($data);
        echo "<script language='javascript'>alert('Berhasil Diubah');</script>";
        redirect('biaya', 'refresh');
    }

    public function delete_biaya($id_biaya)
    {
        $this->master_m->delete_biaya($id_biaya);
        echo "<script language='javascript'>alert('Berhasil Dihapus');</script>";
        redirect('biaya', 'refresh');
    }

    // Hitung
    public function hitung()
    {
        $data['form'] = 'Hitung Offset';
        $data['mesin'] = json_decode($this->master_m->get_mesin(), true);
        $data['paper'] = json_decode($this->master_m->get_bahan(), true);
        $data['biaya'] = json_decode($this->master_m->get_biaya(), true);
        $this->load->view('template/header_dash');
        $this->load->view('template/topbar_dash');
        $this->load->view('template/sidebar_dash');
        $this->load->view('admin/hitung', $data);
        $this->load->view('template/footer_dash');
        $this->load->view('template/footer_js');
    }

    public function hasil_hitung()
    {

        if (!empty($_POST['submit'])) {
            $warna = $this->input->post('quantity_warna');
            $harga_warna = $warna * 1000;
            $area_mesin = $this->input->post('mesin');
            $hasil_array = explode('/', $area_mesin);

            $id_mesin = $hasil_array[0];
            $area_mesin_p = $hasil_array[1];
            $area_mesin_l = $hasil_array[2];

            $area_bahan_p = $this->input->post('p');
            $area_bahan_l = $this->input->post('l');
            $cetak_sisi_finiis = $this->input->post('sisi_finishing');
            $finishing = $this->input->post('finishing');

            $harga_bahan = $this->input->post('kertas');
            $hasil_array_bahan = explode('/', $harga_bahan);
            $id_bahan = $hasil_array_bahan[0];
            $harga_b = $hasil_array_bahan[1];

            $bahan = $harga_b;

            $cetak_sisi = $this->input->post('muka');
            $jumlah_cetak = $this->input->post('jumlah_c');
            $ukuran_cetak_p = $this->input->post('p');
            $ukuran_cetak_l = $this->input->post('l');

            //option 1
            $plano_mata_1 = $area_mesin_p / $area_bahan_p;
            $plano_mata_2 = $area_mesin_l / $area_bahan_l;

            //option 2
            $plano2_mata_1 = $area_mesin_p / $area_bahan_l;
            $plano2_mata_2 = $area_mesin_l / $area_bahan_p;

            //total option 1
            $result_plano1 = round($plano_mata_1) * round($plano_mata_2);
            $result_plano2 = round($plano2_mata_1) * round($plano2_mata_2);

            //subtotal plano 1
            $subtotal_plano_1 = $jumlah_cetak / $result_plano1;
            $subtotal_plano_2 = $jumlah_cetak / $result_plano2;

            // harga bahan 1
            $harga_paper_1 = $subtotal_plano_1 * $bahan;

            //harga bahan 2
            $harga_paper_2 = $subtotal_plano_2 * $bahan;

            //cetak sisi 1 muka
            $harga_cetak_sisi = $subtotal_plano_1 * $cetak_sisi;

            // // cetak sisi 2 muka
            // $cetak_sisi_2_muka_1 = ($subtotal_plano_1 * ($cetak_sisi * 2));
            // $cetak_sisi_2_muka_2 = ($subtotal_plano_2 * ($cetak_sisi * 2));

            //finishing
            $hasil_finis_1_muka_1 = $result_plano1 / 2;
            $hasil_finis_2_muka_2 = $result_plano2 / 2;
            $hitung_finis_1_muka = $subtotal_plano_1 / $hasil_finis_1_muka_1 * $finishing;
            $hitung_finis_2_muka = ($subtotal_plano_1 / $hasil_finis_1_muka_1) * ($finishing) * 2;

            //warna
            $warna_hitung_op_1_1 = $subtotal_plano_1 * $harga_warna;

            $warna_hitung_op_2_1 = $subtotal_plano_2 * $harga_warna;


            echo "Plano_1 : " . $subtotal_plano_1;
            echo "<br>";
            echo "Plano_2 : " . round($subtotal_plano_2);
            echo "<br>";
            echo "Harga_bahan_A4_1 : " . $harga_paper_1;
            echo "<br>";
            echo "Harga_bahan_A4_2: " . round($harga_paper_2);
            echo "<br>";
            echo "Cetak Sisi : " . $harga_cetak_sisi;
            echo "<br>";
            echo "Finishing 1 Muka Option 1 : " . $hitung_finis_1_muka;
            echo "<br>";
            echo "Finishing 2 Muka Option 2 : " . $hitung_finis_2_muka;
            echo "<br>";
            echo "Warna 4 Option 1 : " . round($warna_hitung_op_1_1);
            echo "<br>";
            echo "Warna 4 Option 2 : " . round($warna_hitung_op_2_1);

            echo "<br>";
            // total

            $total_page = ($harga_paper_1 + $harga_cetak_sisi + $hitung_finis_2_muka + $warna_hitung_op_1_1 + 450000) / $jumlah_cetak;
            echo "Total Harga per A4 : " . $total_page . "/pcs";
            $data = array(
                'id_mesin' => $id_mesin,
                'id_bahan' => $id_bahan,
                'jumlah_min' => $this->input->post('jumlah_min'),
                'harga_min' => $this->input->post('harga_min'),
                'harga_lebih' => $this->input->post('harga_lebih'),
                'publish' => $this->input->post('publish')
            );
            $this->master_m->edit_biaya($data);
            echo "<script language='javascript'>alert('Berhasil Diubah');</script>";
            redirect('biaya', 'refresh');
        }
    }

    public function test()
    {
        $this->load->view('admin/test');
    }

    public function test2()
    {
        $this->load->view('admin/test2');
    }

    public function logout()
    {
        $this->session->sess_destroy();
        echo "<script language='javascript'>alert('Berhasil Logout');</script>";
        redirect('admin', 'refresh');
    }
}

/* End of file Admin.php */
