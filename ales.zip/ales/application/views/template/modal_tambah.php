<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Data <?= $form ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('add-bahan') ?>" method="post">
                    <div class="form-group">
                        <label>Nama Bahan</label>
                        <input type="text" name="nama_b" class="form-control" required>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label>Panjang</label>
                                <input type="number" name="bahan_p" class="form-control" required>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label>Lebar</label>
                                <input type="number" name="bahan_l" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group input-group">
                        <label class="input-group">Ketebalan Bahan</label>
                        <input type="number" name="ketebalan_b" class="form-control" required>
                        <div class="input-group-append">
                            <span class="input-group-text">
                                Gsm
                            </span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Harga Bahan</label>
                        <input type="text" name="harga_b" id="rupiah" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label>Publish ?</label><br>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="publish" id="inlineRadio1" value="Yes">
                            <label class="form-check-label" for="inlineRadio1">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="publish" id="inlineRadio2" value="No">
                            <label class="form-check-label" for="inlineRadio2">No</label>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-warning" data-dismiss="modal"><i class="fas fa-times"></i>&nbsp;Close</button>
                <button type="submit" name="submit" class="btn btn-primary"><i class="far fa-save"></i>&nbsp;Simpan</button>
            </div>
            </form>
        </div>
    </div>
</div>