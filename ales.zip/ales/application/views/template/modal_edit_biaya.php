<?php foreach ($biaya['biaya_datab'] as $v) :
    $id_biaya = $v['id_biaya'];
    $jenis_biaya = $v['jenis_biaya'];
    $harga = $v['harga'];
    // $jumlah_min = $v['jumlah_min'];
    // $harga_min = $v['harga_min'];
    // $harga_lebih = $v['harga_lebih'];
    $publish = $v['publish'];
    ?>
    <!-- Modal -->
    <div class="modal fade" id="edit<?= $id_biaya ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ubah Data <?= $form ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?= base_url('edit-biaya') ?>" method="post">
                        <input type="hidden" name="id_biaya" value="<?= $id_biaya ?>">
                        <div class="form-group">
                            <label>Jenis Biaya</label>
                            <input type="text" name="jenis_biaya" value="<?= $jenis_biaya ?>" class="form-control" required>
                        </div>

                        <!-- <div class="form-group">
                            <label>Jumlah Minimal</label>
                            <input type="number" name="jumlah_min" value="<//?= $jumlah_min ?>" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Harga Minimal</label>
                            <input type="text" name="harga_min" id="harga_min3" value="<//?= $harga_min ?>" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Harga Lebih</label>
                            <input type="text" name="harga_lebih" id="harga_lebih2" value="<//?= $harga_lebih ?>" class="form-control" required>
                        </div> -->

                        <div class="form-group">
                            <label>Harga</label>
                            <input type="text" name="harga" id="harga2" value="<?= $harga ?>" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Publish ?</label><br>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="publish" id="inlineRadio1" value="Yes" <?php if ($publish == 'Yes') {
                                                                                                                                    echo 'checked';
                                                                                                                                } ?>>
                                <label class="form-check-label" for="inlineRadio1">Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="publish" id="inlineRadio2" value="No" <?php if ($publish == 'admin') {
                                                                                                                                    echo 'checked';
                                                                                                                                } ?>>
                                <label class="form-check-label" for="inlineRadio2">No</label>
                            </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-dismiss="modal"><i class="fas fa-times"></i>&nbsp;Close</button>
                    <button type="submit" name="submit" class="btn btn-primary"><i class="far fa-save"></i>&nbsp;Simpan</button>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; ?>