<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Data <?= $form ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?= base_url('add-mesin') ?>" method="post">
                    <div class="form-group">
                        <label>Nama Mesin</label>
                        <input type="text" name="m_name" class="form-control" required>
                    </div>

                    <div class="row">
                        <div class="col">
                            <div class="form-group">
                                <label>Ukuran Panjang</label>
                                <input type="number" name="ukuran_max" class="form-control" required>
                            </div>
                        </div>
                        <div class="col">
                            <div class="form-group">
                                <label>Ukuran Lebar</label>
                                <input type="number" name="ukuran_min" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Harga Cetak</label>
                        <input type="text" name="harga_min" id="harga_min" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label>Harga CTP</label>
                        <input type="text" name="harga_ctp" id="harga_ctp" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label>Insheet</label>
                        <input type="number" name="insheet" id="insheet" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label>Publish ?</label><br>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="publish" id="inlineRadio1" value="Yes">
                            <label class="form-check-label" for="inlineRadio1">Yes</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="publish" id="inlineRadio2" value="No">
                            <label class="form-check-label" for="inlineRadio2">No</label>
                        </div>
                    </div>


            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-warning" data-dismiss="modal"><i class="fas fa-times"></i>&nbsp;Close</button>
                <button type="submit" name="submit" class="btn btn-primary"><i class="far fa-save"></i>&nbsp;Simpan</button>
            </div>
            </form>
        </div>
    </div>
</div>