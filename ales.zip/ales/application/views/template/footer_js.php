<!-- REQUIRED SCRIPTS -->

<!-- jQuery -->
<script src="<?= base_url('template/') ?>plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?= base_url('template/') ?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="<?= base_url('template/') ?>plugins/datatables/jquery.dataTables.js"></script>
<script src="<?= base_url('template/') ?>plugins/datatables/dataTables.bootstrap4.js"></script>
<!-- FastClick -->
<script src="<?= base_url('template/') ?>plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE -->
<script src="<?= base_url('template/') ?>dist/js/adminlte.js"></script>

<!-- OPTIONAL SCRIPTS -->
<script src="<?= base_url('template/') ?>plugins/chart.js/Chart.min.js"></script>
<script src="<?= base_url('template/') ?>dist/js/demo.js"></script>
<script src="<?= base_url('template/') ?>dist/js/pages/dashboard3.js"></script>
<script src="<?= base_url('template/') ?>dist/js/jquery.maskMoney.min.js" type="text/javascript"></script>

<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>

<!-- page script -->
<script>
    $(document).ready(function() {
        $(function() {
            $("#example1").DataTable();
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": true,
            });
        });
    });

    $(document).ready(function() {
        $(function() {
            $('#rupiah').maskMoney({
                prefix: '',
                thousands: '.',
                decimal: ',',
                precision: 0
            });
            $('#rupiah2').maskMoney({
                prefix: '',
                thousands: '.',
                decimal: ',',
                precision: 0
            });
            $('#harga_min').maskMoney({
                prefix: '',
                thousands: '.',
                decimal: ',',
                precision: 0
            });
            $('#harga_ctp2').maskMoney({
                prefix: '',
                thousands: '.',
                decimal: ',',
                precision: 0
            });
            $('#harga_min2').maskMoney({
                prefix: '',
                thousands: '.',
                decimal: ',',
                precision: 0
            });
            $('#harga_lebih').maskMoney({
                prefix: '',
                thousands: '.',
                decimal: ',',
                precision: 0
            });
            $('#harga_min3').maskMoney({
                prefix: '',
                thousands: '.',
                decimal: ',',
                precision: 0
            });
            $('#harga_lebih2').maskMoney({
                prefix: '',
                thousands: '.',
                decimal: ',',
                precision: 0
            });

            $('#harga').maskMoney({
                prefix: '',
                thousands: '.',
                decimal: ',',
                precision: 0
            });

            $('#harga2').maskMoney({
                prefix: '',
                thousands: '.',
                decimal: ',',
                precision: 0
            });
        })
    });

    $(document).ready(function() {
        $('select').selectpicker();
    });
</script>

</body>

</html>