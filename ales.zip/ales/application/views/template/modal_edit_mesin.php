<?php foreach ($mesin['mesin_datab'] as $v) :
    $mesin_id = $v['mesin_id'];
    $m_name = $v['m_name'];
    $ukuran_max = $v['ukuran_max'];
    $ukuran_min = $v['ukuran_min'];
    $harga_min = $v['harga_min'];
    $harga_ctp = $v['harga_ctp'];
    $insheet = $v['insheet'];
    $publish = $v['publish'];
    ?>
    <!-- Modal -->
    <div class="modal fade" id="edit<?= $mesin_id ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ubah Data <?= $form ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?= base_url('edit-mesin') ?>" method="post">
                        <input type="hidden" name="mesin_id" value="<?= $mesin_id ?>">
                        <div class="form-group">
                            <label>Nama Mesin</label>
                            <input type="text" name="m_name" value="<?= $m_name ?>" class="form-control" required>
                        </div>

                        <div class="row">
                            <div class="col">
                                <div class="form-group">
                                    <label>Ukuran Panjang</label>
                                    <input type="number" name="ukuran_max" value="<?= $ukuran_max ?>" class="form-control" required>
                                </div>
                            </div>
                            <div class="col">
                                <div class="form-group">
                                    <label>Ukuran Lebar</label>
                                    <input type="number" name="ukuran_min" value="<?= $ukuran_min ?>" class="form-control" required>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Harga Cetak</label>
                            <input type="text" name="harga_min" id="harga_min2" value="<?= $harga_min ?>" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Harga CTP</label>
                            <input type="text" name="harga_ctp" id="harga_ctp2" value="<?= $harga_ctp ?>" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Insheet</label>
                            <input type="number" name="insheet" id="insheet" value="<?= $insheet ?>" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label>Publish ?</label><br>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="publish" id="inlineRadio1" value="Yes" <?php if ($publish == 'Yes') {
                                                                                                                                    echo 'checked';
                                                                                                                                } ?>>
                                <label class="form-check-label" for="inlineRadio1">Yes</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="publish" id="inlineRadio2" value="No" <?php if ($publish == 'admin') {
                                                                                                                                    echo 'checked';
                                                                                                                                } ?>>
                                <label class="form-check-label" for="inlineRadio2">No</label>
                            </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-dismiss="modal"><i class="fas fa-times"></i>&nbsp;Close</button>
                    <button type="submit" name="submit" class="btn btn-primary"><i class="far fa-save"></i>&nbsp;Simpan</button>
                </div>
                </form>
            </div>
        </div>
    </div>
<?php endforeach; ?>