<?php
$ukuran_kertas_p = 650;
$ukuran_kertas_l = 900;
$ukuran_paper_p = 297;
$ukuran_paper_l = 210;

$jumlah_cetak = 1000;

$harga_kertas = 5000;
$cetak_sisi = 3000;
$finishing_doff = 1000;
$finishing_glossy = 1000;


$hasil_bagi = $ukuran_kertas_p / $ukuran_paper_p;
$hasil_bagi2 = $ukuran_kertas_l / $ukuran_paper_l;

$hasil_cari2 = $ukuran_kertas_p / $ukuran_paper_l;
$hasil_carii2 = $ukuran_kertas_l / $ukuran_paper_p;

$total = round($hasil_bagi) * round($hasil_bagi2);
$total2 = round($hasil_cari2) * round($hasil_carii2);
$subtotal = $jumlah_cetak / $total;
$subtotal2 = $jumlah_cetak / $total2;

$harga_ker = $harga_kertas * $subtotal;
$harga_cetak_sisi_satu = $subtotal * 1;
$harga_cetak_sisi_dua = $subtotal * 2;

$hasil = $harga_ker + $harga_cetak_sisi_satu;
$hasil2 = $harga_ker + $harga_cetak_sisi_dua;
echo "Option 1 : " . $subtotal;
echo "<br>";
echo "Option 2 : " . round($subtotal2);
echo "<br>";
echo "Total Harga Kertas + Cetak Sisi Satu: " . $hasil;
echo "<br>";
echo "Total Harga Kertas + Cetak Sisi Dua: " . $hasil2;
