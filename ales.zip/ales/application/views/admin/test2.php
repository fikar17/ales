<?php
$warna_1 = 1000;
$warna_2 = 2000;
$warna_3 = 3000;
$warna_4 = 4000;

$area_mesin_p = 650;
$area_mesin_l = 900;

$area_bahan_p = 297;
$area_bahan_l = 210;

$cetak_sisi_1 = 3000;

$finishing = 1000;

$bahan = 5000;

$jumlah_cetak = 1000;

//option 1
$plano_mata_1 = $area_mesin_p / $area_bahan_p;
$plano_mata_2 = $area_mesin_l / $area_bahan_l;

//option 2
$plano2_mata_1 = $area_mesin_p / $area_bahan_l;
$plano2_mata_2 = $area_mesin_l / $area_bahan_p;

//total option 1
$result_plano1 = round($plano_mata_1) * round($plano_mata_2);
$result_plano2 = round($plano2_mata_1) * round($plano2_mata_2);

//subtotal plano 1
$subtotal_plano_1 = $jumlah_cetak / $result_plano1;
$subtotal_plano_2 = $jumlah_cetak / $result_plano2;

// harga bahan 1
$harga_paper_1 = $subtotal_plano_1 * $bahan;

//harga bahan 2
$harga_paper_2 = $subtotal_plano_2 * $bahan;

//cetak sisi 1 muka
$cetak_sisi_1_muka_1 = $subtotal_plano_1 * $cetak_sisi_1;
$cetak_sisi_1_muka_2 = $subtotal_plano_2 * $cetak_sisi_1;

// cetak sisi 2 muka
$cetak_sisi_2_muka_1 = ($subtotal_plano_1 * ($cetak_sisi_1 * 2));
$cetak_sisi_2_muka_2 = ($subtotal_plano_2 * ($cetak_sisi_1 * 2));

//finishing
$hasil_finis_1_muka_1 = $result_plano1 / 2;
$hasil_finis_2_muka_2 = $result_plano2 / 2;
$hitung_finis_1_muka = $subtotal_plano_1 / $hasil_finis_1_muka_1 * $finishing;
$hitung_finis_2_muka = ($subtotal_plano_1 / $hasil_finis_1_muka_1) * ($finishing) * 2;
$hitung_finis_1_muka_1 = $subtotal_plano_2 / $hasil_finis_2_muka_2 * $finishing;
$hitung_finis_2_muka_2 = ($subtotal_plano_2 / $hasil_finis_2_muka_2) * ($finishing) * 2;

//warna
$warna_hitung_op_1_1 = $subtotal_plano_1 * $warna_1;
$warna_hitung_op_1_2 = $subtotal_plano_1 * $warna_2;
$warna_hitung_op_1_3 = $subtotal_plano_1 * $warna_3;
$warna_hitung_op_1_4 = $subtotal_plano_1 * $warna_4;

$warna_hitung_op_2_1 = $subtotal_plano_2 * $warna_1;
$warna_hitung_op_2_2 = $subtotal_plano_2 * $warna_2;
$warna_hitung_op_2_3 = $subtotal_plano_2 * $warna_3;
$warna_hitung_op_2_4 = $subtotal_plano_2 * $warna_4;

echo "Plano_1 : " . $subtotal_plano_1;
echo "<br>";
echo "Plano_2 : " . round($subtotal_plano_2);
echo "<br>";
echo "Harga_bahan_A4_1 : " . $harga_paper_1;
echo "<br>";
echo "Harga_bahan_A4_2: " . round($harga_paper_2);
echo "<br>";
echo "Cetak 1 Muka Option 1 : " . $cetak_sisi_1_muka_1;
echo "<br>";
echo "Cetak 1 Muka Option 2 : " . round($cetak_sisi_1_muka_2);
echo "<br>";
echo "Cetak 2 Muka Option 1 : " . $cetak_sisi_2_muka_1;
echo "<br>";
echo "Cetak 2 Muka Option 2 : " . round($cetak_sisi_2_muka_2);
echo "<br>";
echo "Finishing 1 Muka Option 1 : " . $hitung_finis_1_muka;
echo "<br>";
echo "Finishing 1 Muka Option 2 : " . $hitung_finis_2_muka;
echo "<br>";
echo "Finishing 2 Muka Option 1 : " . round($hitung_finis_1_muka_1);
echo "<br>";
echo "Finishing 2 Muka Option 2 : " . round($hitung_finis_2_muka_2);
echo "<br>";
echo "Warna 4 Option 1 : " . round($warna_hitung_op_1_4);
echo "<br>";
echo "Warna 4 Option 2 : " . round($warna_hitung_op_2_4);

echo "<br>";
// total

$total_page = ($harga_paper_1 + $cetak_sisi_2_muka_1 + $hitung_finis_2_muka + $warna_hitung_op_1_4 + 450000) / $jumlah_cetak;
echo "Total Harga per A4 : " . $total_page . "/pcs";
