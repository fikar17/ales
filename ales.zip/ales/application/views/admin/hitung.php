<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1><?= $form ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Home</a></li>
                        <li class="breadcrumb-item active"><?= $form ?></li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <!-- /.card-header -->
                    <div class="card-header">
                        <h5>Spesifikasi Produk</h5>
                    </div>
                    <div class="card-body">
                        <form method="post" action="<?= base_url('hasil-hitung') ?>">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">Ukuran Cetak</span>
                                </div>
                                <input type="text" name="p" id="p" class="form-control">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">X</span>
                                </div>
                                <input type="text" name="l" id="l" class="form-control">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">cm</span>
                                </div>
                            </div>

                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">Jumlah Cetak</span>
                                </div>
                                <input type="text" name="jumlah_c" id="jumlah_c" class="form-control">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">Lembar</span>
                                </div>
                            </div>

                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">Insheet</span>
                                </div>
                                <input type="text" name="insheet" id="insheet" class="form-control">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">Tarikan</span>
                                </div>
                                <input type="text" name="uk_tar" id="" class="form-control">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" id="basic-addon1">cm</span>
                                </div>
                            </div>

                            <!-- <div class="form-group all">
                            <select class="selectpicker form-control" name="mesin" id="multi" multiple data-live-search="true">
                                <//?php
                                foreach ($mesin['mesin_datab'] as $v) { ?>
                                    <option value="<//?= $v['mesin_id'] ?>"><//?= $v['m_name'] ?> - <//?= $v['ukuran_max'] ?> x <//?= $v['ukuran_min'] ?></option>
                                <//?php } ?>
                            </select>
                        </div> -->

                            <div class="form-group all">
                                <select name="mesin" id="mesin" class="form-control">
                                    <option value="">-- Pilih Mesin --</option>
                                    <?php
                                    foreach ($mesin['mesin_datab'] as $v) { ?>
                                        <option value="<?= $v['mesin_id'] . '/' . $v['ukuran_max'] . '/' . $v['ukuran_min'] ?>"><?= $v['nama_mesin'] ?></option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="form-group all">
                                <select name="kertas" id="kertas" class="form-control">
                                    <option value="">-- Pilih Bahan --</option>
                                    <?php
                                    foreach ($paper['bahan_datab'] as $paper) { ?>
                                        <option value="<?= $paper['id_bahan'] . '/', $paper['harga_b'] ?>"><?= $paper['nama_bahan'] ?></option>
                                    <?php } ?>
                                </select>
                            </div>

                            <div class="form-group all">
                                <select name="muka" id="muka" class="form-control">
                                    <option value="">-- Pilih Sisi --</option>
                                    <option value="3000">Satu Muka</option>
                                    <option value="6000">Dua Muka</option>
                                </select>
                            </div>
                            <div class="card mt-5">
                                <!-- /.card-header -->
                                <div class="card-header">
                                    <h5>Spesifikasi Finishing</h5>
                                </div>
                                <div class="card-body">

                                    <div class="form-group all">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">Jumlah Warna</span>
                                            <div class="number-input">
                                                <button onclick="this.parentNode.querySelector('input[type=number]').stepDown()" class="minus" type="button"></button>
                                                <input class="quantity form-control" min="0" name="quantity_warna" type="number">
                                                <button onclick="this.parentNode.querySelector('input[type=number]').stepUp()" class="plus" type="button"></button>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="form-group all">
                                        <select name="finishing" id="finishing" class="form-control">
                                            <option value="">-- Finishing --</option>
                                            <?php
                                            foreach ($biaya['biaya_datab'] as $key) { ?>
                                                <option value="<?= $key['harga'] ?>"><?= $key['jenis_biaya'] ?></option>
                                            <?php } ?>
                                        </select>
                                    </div>

                                    <div class="form-group all">
                                        <select name="sisi_finishing" id="sisi_finishing" class="form-control">
                                            <option value="">-- Pilih Sisi --</option>
                                            <option value="1">Satu Muka</option>
                                            <option value="2">Dua Muka</option>
                                        </select>
                                    </div>


                                    <div class="form-group">
                                        <input type="submit" class="btn btn-primary" name="submit" value="Hitung">
                                    </div>
                        </form>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->

            </div>
            <!-- /.card-body -->

        </div>
        <!-- /.card -->

</div>


</div>
</div>
</div>

</div>
<!-- /.col -->
</div>
<!-- /.row -->
</section>
</div>