<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Data <?= $form ?></h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?= base_url('dashboard') ?>">Home</a></li>
                        <li class="breadcrumb-item active">Data <?= $form ?></li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Data <?= $form ?></h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">

                <!-- Button trigger modal -->
                <button type="button" class="btn btn-primary mb-4" data-toggle="modal" data-target="#exampleModal">
                    <i class="fas fa-plus-circle"></i>Tambah Data <?= $form ?>
                </button>
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Mesin</th>
                            <th>Ukuran Max</th>
                            <th>Ukuran Min</th>
                            <th>Harga Minimal</th>
                            <th>Harga CTP</th>
                            <th>Insheet</th>
                            <th>Publish</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        foreach ($mesin['mesin_datab'] as $key) { ?>
                            <tr>
                                <td><?= $no++; ?></td>
                                <td><?= $key['m_name'] ?></td>
                                <td><?= $key['ukuran_max'] ?></td>
                                <td><?= $key['ukuran_min'] ?></td>
                                <td><?= $key['harga_min'] ?></td>
                                <td><?= $key['harga_ctp'] ?></td>
                                <td><?= $key['insheet'] ?></td>
                                <td><?= $key['publish'] ?></td>
                                <td>
                                    <button type="button" class="btn btn-success" data-toggle="modal" data-target="#edit<?= $key['mesin_id'] ?>">
                                        <i class="fas fa-edit"></i>Ubah
                                    </button>
                                    <a href="<?= base_url('delete-mesin') ?>/<?= $key['mesin_id']; ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda Yakin?')">
                                        <i class="fas fa-trash"></i>
                                        Hapus
                                    </a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
            <!-- /.card-body -->
        </div>
        <!-- /.card -->
</div>
<!-- /.col -->
</div>
<!-- /.row -->
</section>
</div>

<?php $this->load->view('template/modal_tambah_mesin'); ?>
<?php $this->load->view('template/modal_edit_mesin'); ?>